/* catTown.js

This is a simulation of a cat chasing a computer-controlled mouse ("raton" to avoid confusion) around a track.

The user controls the cat with a mouse, governed to a maximum speed.

11/3/2023 Peter Weinstein. Created.

*/

// global variables
var cat;

function setup() {
  createCanvas(400, 300);
  this.cat = new Cat(100, 100, 60, -45);
}

function draw() {
  background(220);
  this.cat.draw(mouseX, mouseY);
}

/* This class represents a user-controlled cat.
*/
class Cat {
  constructor(x, y, bodyLen, angle) {
    this.prevX = x;   // x where the head meets body
    this.prevY = y;
    this.prevAngle = angle;
    this.bodyLen = bodyLen;
  }
  
  /* draws the cat at the location of the computer mouse; 
     or the location that is as far as the cat could
     have moved from the previous location since the
     last display, in the direction towards the mouse
     location.
     the exact location of the cat is where the neck joins the body.
     the angle of the cat is determined by the mouse
     location now and previously.
     
  */
  draw(x, y) {
    var deltaY = y - this.prevY;
    var deltaX = x - this.prevX;
    var angle = this.prevAngle;
    if (deltaX != 0)
        angle = atan(deltaY / deltaX);
    else if (deltaY > 0)
        angle = Math.PI/2;
    else if (deltaY < 0)
        angle = -Math.PI/2;
    this.prevX = x;
    this.prevY = y;
    this.prevAngle = angle;
    var w = int(this.bodyLen/3);    // body width
    var signX = 1;
    if (deltaX < 0)
      signX = -1;
    var signY = 1;
    if (deltaX < 0)
      signY = -1;
    // draw body
    push();
    translate(x - signX * (this.bodyLen/2 * cos(angle)), 
              y - signX * (this.bodyLen/2 * sin(angle)));
    rotate(angle);  // * 180 / Math.PI);
    ellipse(0, 0, this.bodyLen, w);
    pop();
    // draw head
    var hr = int(this.bodyLen/10);  // head radius
    circle(x + signX * hr * cos(angle),
           y + signX * hr * sin(angle),
           hr * 2);
  }
}