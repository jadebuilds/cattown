/* catTown.js

This is a simulation of a cat chasing a computer-controlled mouse ("raton" to avoid confusion) around a track.

The user controls the cat with a mouse, governed to a maximum speed.

11/3/2023 Peter Weinstein. Drag two-ellipse cat with mouse.
11/7/2023 Peter. Smooth and govern the cat's movement. Draw track.
11/9/2023 Peter. Draw mouse, run along track.
11/14/2023 Peter. Run counterclockwise.
*/

// global variables
var cat;
var track;
var raton;    // "mouse" in Spanish
var raton2;
// constants
// direction of mouse movement
var CLOCKWISE = 1;
var COUNTERCLOCKWISE = -1;
// indices for track vertices (PENDING: use objects instead)
var X = 0;
var Y = 1;
var mouseHouseLength = 30;
var mouseHouseWidth = 18;

// initialize the simulation
function setup() {
  createCanvas(400, 300);
  this.cat = new Cat(100, 100, 60, -45);
  // the track is a closed polygon
  var vertices = [[50, 50], [150, 30], [200, 140], [300, 120],
                  [300, 220], [150, 200], [50, 100]];
  // mouse houses (casa de raton) are located by the segment, and percentage
  // of how far the center is from the first vertex when moving clockwise.
  var mouseHouses = [[1, 50], [4, 40]];
  this.track = new Track(vertices, 10, mouseHouses);
  this.raton = new Raton(vertices[0][0], vertices[0][1], 0, 15, CLOCKWISE);
  this.raton2 = new Raton(vertices[0][0], vertices[0][1], 0, 15, COUNTERCLOCKWISE);
}

// redraws the screen approximately 60 times per second
function draw() {
  background(220);
  this.track.draw();
  this.cat.draw(mouseX, mouseY);
  this.raton.draw(1.5, CLOCKWISE, this.track);  
  //this.raton2.draw(1.5, COUNTERCLOCKWISE, this.track);  
}

// returns the angle of the vector from point1 to point2
function calcAngle(x1, y1, x2, y2, defaultAngle = 0) {
    var deltaY = y2 - y1;
    var deltaX = x2 - x1;        
    var angle;
    if (deltaX == 0 && deltaY == 0)
      angle = defaultAngle;
    else if (deltaX != 0) 
    {
      angle = atan(deltaY / deltaX);
      // the arctangent function returns angles from -pi/2 to pi/2.
      // if the delta is to the left we add 180 degrees.
      if (deltaX < 0)
        angle += Math.PI;
    }
    else if (deltaY > 0)
      angle = Math.PI/2;
    else if (deltaY < 0)
      angle = -Math.PI/2;
    return angle;
}


/* This class represents a user-controlled cat.
*/
class Cat {
  constructor(x, y, bodyLen, angle) {
    this.prevX = x;   // x where the head meets body
    this.prevY = y;
    this.prevSignX = 1;
    this.prevAngle = angle;
    this.bodyLen = bodyLen;
    
    // parameters
    this.maxAngleDelta = Math.PI / 60;
    this.maxDistanceDelta = 10;
  }
  
  /* draws the cat at the location of the computer mouse; 
     or the location that is as far as the cat could
     have moved from the previous location since the
     last display, in the direction towards the mouse
     location.
     the exact location of the cat is where the neck joins the body.
     the angle of the cat is determined by the mouse
     location now and previously.
     
  */
  draw(x, y) {
    // PENDING: use calcAngle() function
    var deltaY = y - this.prevY;
    var deltaX = x - this.prevX;
    
    // the arctangent function returns angles from -pi/2 to pi/2.
    // if the cat is moving left we flip 180 degrees.
    var signX = this.prevSignX;
    if (deltaX > 0)
      signX = 1;
    else if (deltaX < 0)
      signX = -1;
    
    // adjust angle
    var angle = this.prevAngle;
    if (deltaX == 0 && deltaY == 0) {
      angle = this.prevAngle;
      signX = this.prevSignX;
    }
    else if (deltaX != 0)
        angle = atan(deltaY / deltaX);
    else if (deltaY > 0)
        angle = Math.PI/2;
    else if (deltaY < 0)
        angle = -Math.PI/2;
    //print(angle, this.prevAngle, angle - this.prevAngle, signX, this.prevSignX);
    // constrain change of angle
    if (Math.abs(angle - this.prevAngle) > this.maxAngleDelta) 
    {
        if (angle > this.prevAngle)
          angle = this.prevAngle + this.maxAngleDelta;
        else
          angle = this.prevAngle - this.maxAngleDelta;
    }
    if (angle > 2 * Math.PI)
      angle -= 2 * Math.PI;
    else if (angle < -2 * Math.PI)
      angle += 2 * Math.PI;
    
    this.prevX = x;
    this.prevY = y;
    this.prevSignX = signX;
    this.prevAngle = angle;
    
    // draw body
    push();
    translate(x - signX * (this.bodyLen/2 * cos(angle)), 
              y - signX * (this.bodyLen/2 * sin(angle)));
    rotate(angle);  // * 180 / Math.PI);
    var w = int(this.bodyLen/3);    // body width
    ellipse(0, 0, this.bodyLen, w);
    pop();
    // draw head
    var hr = int(this.bodyLen/10);  // head radius
    circle(x + signX * hr * cos(angle),
           y + signX * hr * sin(angle),
           hr * 2);
  }
}

/* This class represents the track. 
   The vertices must define the track in a clockwise direction.
   The raton runs back and forth on this track.
*/
class Track {
  constructor(vertices, vdiameter, mouseHouses) {
    this.vdiameter = vdiameter;
    // close the track vertices into a loop looking two ahead as needed to draw it.
    this.vertices = [];
    arrayCopy(vertices, this.vertices);
    var v1 = [vertices[0][0], vertices[0][1]];
    var v2= [vertices[1][0], vertices[1][1]];
    this.vertices.push(v1);
    this.vertices.push(v2);
    this.mouseHouses = mouseHouses;
    print("track: ");
    print(this.vertices);
    print("mouse houses as segment/percent traversed:")
    print(this.mouseHouses);
  }
  
  getTrueLength() 
  {
    return this.vertices.length - 2;
  }
  
  getPrevSegment(segment)
  {
    if (segment == 0)
      return getTrueLength();
    else
      return segment - 1;
  }
  
  getX(segment)
  {
    return this.vertices[segment][X];
  }

  getY(segment)
  {
    return this.vertices[segment][Y];
  }
  
  getSegmentSlope(segment, direction)
  {
    var seg = segment;
    if (segment == 0 && direction == COUNTERCLOCKWISE)
      seg = this.getTrueLength();
    var deltaX = this.vertices[seg + direction][X] - this.vertices[seg][X];
    //print(seg, seg + direction, deltaX);
    if (deltaX == 0)
      return undefined;  // vertical
    else {
      var deltaY = this.vertices[seg + direction][Y] - this.vertices[seg][Y];
        return deltaY / deltaX;  
    }
  }
  
  // a segment goes left if x becomes smaller
  segmentGoesLeft(segment, direction)
  {
    var seg = segment;
    if (seg <= 0)
      seg = this.getTrueLength();
    var deltaX = this.vertices[seg + direction][X] - this.vertices[seg][X];
    return deltaX < 0;
  }
  
  // in p5js, a vertical segment goes up if y becomes smaller
  segmentGoesUp(segment, direction)
  {
    var seg = segment;
    if (seg <= 0)
      seg = this.getTrueLength();
    var deltaY = this.vertices[seg + direction][Y] - this.vertices[seg][Y];
    return deltaY < 0;
  }
  
  // pending: depend on the orientation of the segment
  isInSegment(x, y, segment, direction)
  {
    var seg = segment + direction;
    if (seg < 0 && direction == COUNTERCLOCKWISE)
        seg = this.getTrueLength() - 1;
    // use the X coordinate to tell when the raton is past the segment,
    // or Y for vertical segments
    var limitDim = X;
    if (this.getX(segment) == this.getX(seg))
      limitDim = Y;
    var limit = this.vertices[seg][X];
    var cur = x;
    if (limitDim == Y)
    {
      //print("vertical segment", segment);
      limit = this.vertices[seg][Y];
      cur = y;
    }
    // check the boundary depending on segment orientation and direction
    if (limitDim == X)
    {
      if (this.segmentGoesLeft(segment, direction))
        return cur > this.vertices[seg][limitDim];
    else
        return cur < this.vertices[seg][limitDim];
    } 
    else
    {
      if (this.segmentGoesUp(segment, direction))
        return cur > this.vertices[seg][limitDim];
    else
        return cur < this.vertices[seg][limitDim];      
    }
  }
  
  // return changes in x and y to move a distance along a segment. also the angle.
  displacement(segment, distance, direction)
  {
    var slope = track.getSegmentSlope(segment, direction);
    var angle;    
    if (slope == undefined)  // vertical line
    {
      var yDir = this.segmentGoesUp(segment, direction) ? -1 : 1;
      return [0, yDir * distance, undefined];    
    }
    else
      angle = atan(slope);
    if (this.segmentGoesLeft(segment, direction))
      angle += Math.PI;
    var deltaY = distance * sin(angle);
    var deltaX = distance * cos(angle);
    return [deltaX, deltaY, angle];
  }
  
  draw() {
    var vs = this.vertices;
    // draw each segment of the track
    for (let i=0; i < this.getTrueLength(); i++)
    {
      line(vs[i][X], vs[i][Y], vs[i+1][X], vs[i+1][Y]);
      // draw the pivot. PENDING: locate correctly.
      push();
      noFill();
      arc(vs[i+1][X], vs[i+1][Y], 
          this.vdiameter, this.vdiameter,
          0, 2 * Math.PI);
      pop();
    }
    // draw each mouse house
    rectMode(CENTER);
    for (let i=0; i < this.mouseHouses.length; i++)
    {
      var seg = this.mouseHouses[i][0];
      var pctTraversed = this.mouseHouses[i][1];
      var x1 = this.vertices[seg][X];
      var x2 = this.vertices[seg + 1][X];
      var y1 = this.vertices[seg][Y];
      var y2 = this.vertices[seg + 1][Y];
      var houseX = x1 + pctTraversed / 100 * (x2 - x1);
      var houseY = y1 + pctTraversed / 100 * (y2 - y1);
      push();
      translate(houseX, houseY);
      rotate(calcAngle(x1, y1, x2, y2));
      rect(0, 0, mouseHouseLength, mouseHouseWidth);
      pop();
    }
  }
    
}

/* This class represents the raton (mouse in Spanish).
*/
class Raton {
  constructor(x, y, segment, bodyLen, direction) {
    this.prevX = x;   // x where the head meets body
    this.prevY = y;
    this.prevSegment = segment;  // segment of track
    this.prevDirection = CLOCKWISE;
    this.bodyLen = bodyLen;
    
    // parameters
    this.maxSpeed = 4;
  }
  
  /* draws the raton at the new location, a distance from its previous
     location based on its current speed.     
  */
  draw(s, direction, track) {
    var segment = this.prevSegment;    
    var displacement = track.displacement(segment, s, direction);
    var deltaX = displacement[0];
    var deltaY = displacement[1];
    var angle = displacement[2];
    if (angle == undefined)
    {
      if (deltaY > 0)
        angle = Math.PI / 2;
      else
        angle = -Math.PI / 2;
    }
    var x = this.prevX + deltaX;
    var y = this.prevY + deltaY;
    // debug movement
    //print(segment, x, y, displacement[2]);
    this.prevX = x;
    this.prevY = y;
    if (!track.isInSegment(x, y, segment, direction))
    {
      this.prevSegment = segment + direction; 
      // check for start of a new lap
      if(this.prevSegment >= track.getTrueLength() && direction == CLOCKWISE)
        this.prevSegment = 0;
      else if (this.prevSegment < 0 && direction == COUNTERCLOCKWISE)
        this.prevSegment = track.getTrueLength();
      // avoid accumulating rounding errors by placing raton exactly on track
      var dx = x - track.getX(this.prevSegment);
      var dy = y - track.getY(this.prevSegment);
      var dist = Math.sqrt(dx * dx + dy * dy); // distance from segment beginning
      var disp = track.displacement(this.prevSegment, dist, direction);
      this.prevX = track.getX(this.prevSegment) + disp[0];
      this.prevY = track.getY(this.prevSegment) + disp[1];
    } 
    
    // adjust for angles not in the domain of the arc tangent function
    var signX = 1;
    
    // draw body
    push();
    translate(x - signX * (this.bodyLen/2 * cos(angle)), 
              y - signX * (this.bodyLen/2 * sin(angle)));
    rotate(angle);  // * 180 / Math.PI);
    var w = int(this.bodyLen/1.65);    // body width
    ellipse(0, 0, this.bodyLen, w);
    pop();
    // draw head
    var hr = int(this.bodyLen/3.2);  // head radius
    circle(x + signX * hr * cos(angle),
           y + signX * hr * sin(angle),
           hr * 2);
  }
}
